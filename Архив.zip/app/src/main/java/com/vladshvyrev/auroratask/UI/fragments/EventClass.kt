package com.vladshvyrev.auroratask.UI.fragments

class EventClass(var mValue: ArrayList<String>)